-- ============================================================
-- 示例插件 - LXC-LUA 插件 API 演示
-- 演示分类化插件桥接 API 的使用方法
-- ============================================================

-- API 模块说明:
-- plugin.sys:     系统操作（日志、Toast、版本等）
-- plugin.editor:  编辑器操作（文本、光标、文件、语言检测等）
-- plugin.project: 项目操作（文件读写、目录等）
-- plugin.ui:      对话框操作（消息、确认、输入等）
-- plugin.events:  事件监听（注册、触发事件）
-- plugin.config:  配置存储（键值持久化）
-- plugin.reflect: Java 反射（类、方法、字段）
-- plugin.lua:     Lua 脚本执行
-- plugin.menu:    菜单管理（快捷操作、菜单项）
-- plugin.clipboard: 剪贴板操作
-- plugin.http:    网络请求
-- plugin.manager: 插件管理（信息获取、启用禁用）
-- plugin.nav:     导航与侧滑栏（添加菜单项）

-- 1. 系统操作示例 - 检查版本和日志
local version = plugin.sys.getVersion()
local dataDir = plugin.sys.getDataDir()
plugin.sys.log("示例插件", "插件已加载, IDE 版本: " .. tostring(version))
plugin.sys.log("示例插件", "插件数据目录: " .. tostring(dataDir))

-- 2. 配置存储示例
local greetCount = plugin.config.getInt("greet_count", 0)
plugin.config.setInt("greet_count", greetCount + 1)
plugin.sys.log("示例插件", "插件启动次数: " .. (greetCount + 1) .. " 次")

-- 3. 添加编辑器快捷操作按钮
plugin.menu.addQuickAction("greet", "问候", function()
    plugin.sys.toast("你好！这是第 " .. plugin.config.getInt("greet_count", 0) .. " 次启动插件")
end)

-- 4. 插入注释按钮
plugin.menu.addQuickAction("insert_comment", "插入注释", function()
    plugin.editor.insertText("-- TODO: ")
end)

-- 5. 显示选中文本按钮
plugin.menu.addQuickAction("show_selection", "显示选区", function()
    local ok, result = pcall(function()
        return plugin.editor.getSelectedText()
    end)
    
    if ok and result and #result > 0 then
        plugin.sys.toast("选中内容: " .. result)
    else
        local ok2, cursor = pcall(function()
            return plugin.editor.getCursorPosition()
        end)
        
        if ok2 and cursor then
            plugin.sys.toast("光标位置: 行 " .. tostring(cursor[1] + 1) .. ", 列 " .. tostring(cursor[2] + 1))
        else
            plugin.sys.toast("请先打开一个文件")
        end
    end
end)

-- 6. 跳转到指定行
plugin.menu.addQuickAction("goto_line", "跳转到行", function()
    local callback = {
        onInput = function(text)
            local line = tonumber(text)
            if line then
                plugin.editor.gotoLine(line - 1)
                plugin.sys.toast("已跳转到第 " .. line .. " 行")
            else
                plugin.sys.toast("请输入有效的行号")
            end
        end
    }
    plugin.ui.showInputDialog("跳转到行", "请输入行号", "1", callback)
end)

-- 7. 显示确认对话框
plugin.menu.addQuickAction("show_dialog", "显示对话框", function()
    plugin.ui.showConfirm("确认操作", "确定要执行此操作吗？", function()
        plugin.sys.toast("你点击了确定")
    end, function()
        plugin.sys.toast("你点击了取消")
    end)
end)

-- 8. 复制文件路径
plugin.menu.addQuickAction("copy_file_path", "复制路径", function()
    local filePath = plugin.editor.getActiveFile()
    if filePath then
        plugin.clipboard.copy(filePath)
        plugin.sys.toast("已复制: " .. filePath)
    else
        plugin.sys.toast("没有打开的文件")
    end
end)

-- 9. 文件信息
plugin.menu.addQuickAction("file_info", "文件信息", function()
    local filePath = plugin.editor.getActiveFile()
    local projectPath = plugin.project.getPath()
    
    if filePath then
        local info = "当前文件: " .. filePath .. "\n"
        info = info .. "项目路径: " .. tostring(projectPath)
        plugin.ui.showMessage("文件信息", info)
    else
        plugin.sys.toast("没有打开的文件")
    end
end)

-- 10. 检查当前编辑器语言
plugin.menu.addQuickAction("check_language", "检查语言", function()
    local lang = plugin.editor.getLanguage()
    local ext = plugin.editor.getFileExtension()
    local isLua = plugin.editor.isLanguage("lua")
    
    local info = "当前语言: " .. tostring(lang) .. "\n" ..
                 "文件扩展名: " .. tostring(ext) .. "\n" ..
                 "是否 Lua 文件: " .. (isLua and "是" or "否")
    plugin.ui.showMessage("编辑器语言信息", info)
end)

-- 11. 检查应用语言环境（国际化）
plugin.menu.addQuickAction("check_locale", "语言环境", function()
    local lang = plugin.sys.getAppLanguage()
    local region = plugin.sys.getAppRegion()
    local locale = plugin.sys.getAppLocale()
    local isChinese = plugin.sys.isChinese()
    local isEnglish = plugin.sys.isEnglish()
    
    local info = "应用语言: " .. lang .. "\n" ..
                 "应用区域: " .. region .. "\n" ..
                 "完整区域: " .. locale .. "\n" ..
                 "中文环境: " .. (isChinese and "是" or "否") .. "\n" ..
                 "英文环境: " .. (isEnglish and "是" or "否")
    plugin.ui.showMessage("国际化信息", info)
end)

-- 12. Java 反射测试 - 加载类
plugin.menu.addQuickAction("java_load_class", "加载类", function()
    local clazz = plugin.reflect.loadClass("com.luaforge.studio.lxclua.plugin.ReflectionTestClass")
    if clazz then
        plugin.sys.toast("类加载成功: " .. tostring(clazz))
    else
        plugin.sys.toast("类加载失败")
    end
end)

-- 13. Java 反射测试 - 静态字段
plugin.menu.addQuickAction("java_static_field", "静态字段", function()
    local className = "com.luaforge.studio.lxclua.plugin.ReflectionTestClass"
    
    -- 获取当前静态字段值
    local currentValue = plugin.reflect.getStaticField(className, "staticField")
    plugin.sys.log("示例插件", "静态字段当前值: " .. tostring(currentValue))
    
    -- 切换值
    local newValue
    if tostring(currentValue) == "静态字段初始值" then
        newValue = "从 Lua 修改的值"
    else
        newValue = "静态字段初始值"
    end
    
    -- 设置静态字段
    plugin.reflect.setStaticField(className, "staticField", newValue)
    
    -- 再次获取确认
    local confirmValue = plugin.reflect.getStaticField(className, "staticField")
    
    plugin.ui.showMessage("静态字段测试", 
        "修改前: " .. tostring(currentValue) .. "\n" ..
        "修改后: " .. tostring(confirmValue) .. "\n\n" ..
        "再次点击可切换回来")
end)

-- 14. Java 反射测试 - 静态方法
plugin.menu.addQuickAction("java_static_method", "静态方法", function()
    local className = "com.luaforge.studio.lxclua.plugin.ReflectionTestClass"
    
    -- 调用无参静态方法
    local result1 = plugin.reflect.callStaticMethod(className, "staticMethod", nil)
    plugin.sys.log("示例插件", "staticMethod(): " .. tostring(result1))
    
    -- 调用带参数的静态方法
    local result2 = plugin.reflect.callStaticMethod(className, "staticMethodWithParams", {10, 20})
    plugin.sys.log("示例插件", "staticMethodWithParams(10, 20): " .. tostring(result2))
    
    plugin.ui.showMessage("静态方法测试",
        "staticMethod(): " .. tostring(result1) .. "\n" ..
        "staticMethodWithParams(10, 20): " .. tostring(result2))
end)

-- 15. Java 反射测试 - 创建实例
plugin.menu.addQuickAction("java_new_instance", "创建实例", function()
    local className = "com.luaforge.studio.lxclua.plugin.ReflectionTestClass"
    
    -- 无参构造
    local obj1 = plugin.reflect.newInstance(className, nil)
    plugin.sys.log("示例插件", "无参构造: " .. tostring(obj1))
    
    -- 带 String 参数的构造
    local obj2 = plugin.reflect.newInstance(className, {"初始值来自 Lua"})
    plugin.sys.log("示例插件", "String 构造: " .. tostring(obj2))
    
    -- 带 int, int 参数的构造
    local obj3 = plugin.reflect.newInstance(className, {100, 200})
    plugin.sys.log("示例插件", "int,int 构造: " .. tostring(obj3))
    
    local info = "无参构造: " .. tostring(obj1) .. "\n" ..
                 "String 构造: " .. tostring(obj2) .. "\n" ..
                 "int,int 构造: " .. tostring(obj3)
    plugin.ui.showMessage("创建实例测试", info)
end)

-- 16. Java 反射测试 - 实例字段
-- 注意: 使用全局变量保存实例，以便在多次点击间保持状态
local savedInstance = nil

plugin.menu.addQuickAction("java_instance_field", "实例字段", function()
    local className = "com.luaforge.studio.lxclua.plugin.ReflectionTestClass"
    
    -- 如果实例不存在，创建新实例
    if not savedInstance then
        savedInstance = plugin.reflect.newInstance(className, {"测试实例"})
        plugin.sys.log("示例插件", "已创建新实例")
    end
    
    -- 获取当前实例字段值
    local currentValue = plugin.reflect.getField(savedInstance, "instanceField")
    plugin.sys.log("示例插件", "实例字段当前值: " .. tostring(currentValue))
    
    -- 切换值
    local newValue
    if tostring(currentValue) == "测试实例" then
        newValue = "从 Lua 修改"
    elseif tostring(currentValue) == "从 Lua 修改" then
        newValue = "再次修改"
    else
        newValue = "测试实例"
    end
    
    -- 设置实例字段
    plugin.reflect.setField(savedInstance, "instanceField", newValue)
    
    -- 再次获取确认
    local confirmValue = plugin.reflect.getField(savedInstance, "instanceField")
    
    plugin.ui.showMessage("实例字段测试",
        "当前值: " .. tostring(currentValue) .. "\n" ..
        "修改后: " .. tostring(confirmValue) .. "\n\n" ..
        "再次点击继续切换")
end)

-- 17. Java 反射测试 - 实例方法
plugin.menu.addQuickAction("java_instance_method", "实例方法", function()
    local className = "com.luaforge.studio.lxclua.plugin.ReflectionTestClass"
    
    -- 创建实例
    local obj = plugin.reflect.newInstance(className, {"Hello Lua"})
    
    -- 调用无参实例方法
    local result1 = plugin.reflect.callMethod(obj, "instanceMethod", nil)
    plugin.sys.log("示例插件", "instanceMethod(): " .. tostring(result1))
    
    -- 调用带参数的实例方法
    local result2 = plugin.reflect.callMethod(obj, "instanceMethodWithParams", {"测试", 3})
    plugin.sys.log("示例插件", "instanceMethodWithParams: " .. tostring(result2))
    
    -- 调用带返回值的方法
    local result3 = plugin.reflect.callMethod(obj, "increment", nil)
    plugin.sys.log("示例插件", "increment(): " .. tostring(result3))
    
    plugin.ui.showMessage("实例方法测试",
        "instanceMethod(): " .. tostring(result1) .. "\n" ..
        "instanceMethodWithParams: " .. tostring(result2) .. "\n" ..
        "increment(): " .. tostring(result3))
end)

-- 18. 执行 Lua 脚本
plugin.menu.addQuickAction("exec_lua", "执行 Lua", function()
    local result = plugin.lua.execute("return 1 + 2 + 3")
    plugin.sys.toast("计算结果: " .. tostring(result))
end)

-- 19. 添加顶部菜单项
plugin.menu.addMenuItem("hello_menu", "插件消息", function()
    plugin.ui.showMessage("示例插件", "这是从插件菜单项触发的消息！")
end)

plugin.menu.addMenuItem("current_file", "显示当前文件", function()
    local file = plugin.editor.getActiveFile()
    if file then
        plugin.sys.toast("当前文件: " .. file)
    else
        plugin.sys.toast("没有打开的文件")
    end
end)

plugin.menu.addMenuDivider("divider1")

plugin.menu.addMenuItem("insert_date", "插入日期", function()
    local date = plugin.reflect.newInstance("java.util.Date", nil)
    local dateStr = plugin.reflect.callMethod(date, "toString", nil)
    plugin.editor.insertText("-- " .. tostring(dateStr))
end)

-- 20. 监听文件保存事件
plugin.events.register("onFileSave", function(filePath)
    plugin.sys.log("示例插件", "文件已保存: " .. tostring(filePath))
end)

-- 21. 监听文件打开事件
plugin.events.register("onFileOpen", function(filePath)
    local fileName = tostring(filePath):match("[^/]+$") or tostring(filePath)
    plugin.sys.toast("已打开文件: " .. fileName)
end)

-- 22. 文件树上下文菜单示例 - 查看文件信息
plugin.menu.addFileTreeItem("ft_file_info", "查看文件信息", nil, function(filePath, isDirectory)
    local fileInfo = plugin.project.getFileInfo(filePath)
    if fileInfo then
        local info = "名称: " .. tostring(fileInfo.name) .. "\n"
        info = info .. "路径: " .. tostring(fileInfo.path) .. "\n"
        info = info .. "类型: " .. (fileInfo.isDirectory and "目录" or "文件") .. "\n"
        if not fileInfo.isDirectory then
            info = info .. "扩展名: ." .. tostring(fileInfo.extension) .. "\n"
            info = info .. "大小: " .. tostring(fileInfo.size) .. " 字节\n"
            info = info .. "修改时间: " .. os.date("%Y-%m-%d %H:%M:%S", fileInfo.lastModified / 1000) .. "\n"
        end
        info = info .. "父目录: " .. tostring(fileInfo.parentPath)
        plugin.ui.showMessage("文件信息", info)
    else
        plugin.sys.toast("文件不存在")
    end
end)

-- 23. 文件树上下文菜单示例 - 运行 Lua
plugin.menu.addFileTreeItem("ft_run_lua", "运行 Lua", ".lua", function(filePath, isDirectory)
    plugin.sys.toast("正在运行: " .. tostring(filePath))
    local result = plugin.lua.executeFile(filePath)
    plugin.sys.log("示例插件", "Lua 执行结果: " .. tostring(result))
end)

-- 24. 侧滑栏扩展示例 - 添加设置菜单项
plugin.nav.addSidebarItem("plugin_settings", "插件设置", "settings", nil, function()
    plugin.sys.toast("点击了插件设置（侧滑栏菜单项）")
    plugin.ui.showMessage("侧滑栏功能", "这是通过插件动态添加到侧滑栏的菜单项！")
end)

-- 25. 侧滑栏扩展示例 - 添加自定义菜单项
plugin.nav.addSidebarItem("plugin_feature", "插件功能", "custom", nil, function()
    plugin.sys.toast("点击了插件功能")
    plugin.ui.showMessage("自定义侧滑栏项", "此菜单项添加到了 custom 分组")
end)

-- 26. 插件管理信息
plugin.menu.addQuickAction("plugin_info", "插件信息", function()
    local info = "插件 ID: com.example.hello_plugin\n" ..
                 "版本: 1.0.0\n" ..
                 "类型: Lua 插件\n" ..
                 "API 版本: " .. plugin.getApiVersion() .. "\n\n" ..
                 "支持的模块:\n" ..
                 "- sys: 系统操作\n" ..
                 "- editor: 编辑器操作\n" ..
                 "- project: 项目操作\n" ..
                 "- ui: 对话框操作\n" ..
                 "- events: 事件监听\n" ..
                 "- config: 配置存储\n" ..
                 "- reflect: Java 反射\n" ..
                 "- lua: Lua 脚本执行\n" ..
                 "- menu: 菜单管理\n" ..
                 "- clipboard: 剪贴板操作\n" ..
                 "- http: 网络请求\n" ..
                 "- manager: 插件管理\n" ..
                 "- nav: 导航与侧滑栏"
    plugin.ui.showMessage("示例插件信息", info)
end)

-- 27. 测试插件管理功能
plugin.menu.addQuickAction("list_plugins", "插件列表", function()
    local plugins = plugin.manager.getPluginIds()
    if plugins and #plugins > 0 then
        local pluginList = ""
        for i, pluginId in ipairs(plugins) do
            local name = plugin.manager.getPluginName(pluginId) or pluginId
            local version = plugin.manager.getPluginVersion(pluginId) or "未知"
            local enabled = plugin.manager.isPluginEnabled(pluginId) and "✓" or "✗"
            local category = plugin.manager.getPluginCategory(pluginId) or "normal"
            local categoryLabel = plugin.manager.getPluginCategoryLabel(pluginId) or category
            pluginList = pluginList .. i .. ". [" .. enabled .. "] " .. name .. " (v" .. version .. ") - " .. categoryLabel .. "\n"
        end
        plugin.ui.showMessage("已安装插件", pluginList)
    else
        plugin.sys.toast("没有安装的插件")
    end
end)

-- 28. 测试插件分类系统
plugin.menu.addQuickAction("plugin_category", "插件分类", function()
    local categories = {
        {type = "core", label = "核心插件", desc = "系统必需，无法禁用"},
        {type = "normal", label = "普通插件", desc = "可自由启用/禁用"},
        {type = "dependent", label = "附属插件", desc = "依赖其他插件才能运行"},
        {type = "extension", label = "扩展插件", desc = "扩展其他插件的功能"}
    }
    
    local info = "插件分类系统\n\n"
    for i, cat in ipairs(categories) do
        info = info .. cat.label .. ":\n"
        info = info .. "  - 类型标识: " .. cat.type .. "\n"
        info = info .. "  - 说明: " .. cat.desc .. "\n\n"
    end
    
    info = info .. "当前插件分类: " .. (plugin.manager.getPluginCategoryLabel("com.example.hello_plugin") or "未知")
    
    plugin.ui.showMessage("插件分类说明", info)
end)

plugin.sys.log("示例插件", "初始化完成，已注册 13 个快捷操作 + 3 个菜单项 + 2 个侧滑栏项 + 2 个事件监听器")
